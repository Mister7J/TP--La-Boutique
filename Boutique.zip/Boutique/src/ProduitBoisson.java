public class ProduitBoisson extends Produit {
    private int quantite;

    // Constructeur qui initialise les attributs de la classe parente (Produit) et l'attribut spécifique (quantite)
    public ProduitBoisson(String nom, String description, int quantite, int prix) {
        super(nom, description, prix);
        this.quantite = quantite;
    }

    // Méthode pour afficher les informations de la boisson
    @Override
    public void afficher() {
        super.afficher(); // Appelle la méthode afficher() de la classe parente pour afficher les informations générales du produit
        System.out.println("Quantité: " + quantite + " cl"); // Affiche la quantité spécifique à la boisson
    }
}
