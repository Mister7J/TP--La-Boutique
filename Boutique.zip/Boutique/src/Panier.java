import java.util.ArrayList;
import java.util.List;

public class Panier {
    private List<Produit> produits;

    // Constructeur qui initialise la liste des produits
    public Panier() {
        this.produits = new ArrayList<>();
    }

    // Méthode pour ajouter un produit au panier
    public void ajouterProduit(Produit produit) {
        produits.add(produit);
    }

    // Méthode pour calculer le prix total du panier
    public int prixTotalPanier() {
        int total = 0;

        // Parcours tous les produits du panier
        for (Produit produit : produits) {
            total += produit.getPrix(); // Ajoute le prix de chaque produit au total
        }

        return total; // Retourne le prix total du panier
    }
}
