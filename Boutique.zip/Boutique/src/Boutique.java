import java.util.ArrayList;
import java.util.List;

public class Boutique {
    private List<Produit> produits;

    // Constructeur
    public Boutique() {
        produits = new ArrayList<>();
    }

    // Ajouter un produit à la boutique
    public void addProduit(Produit produit) {
        produits.add(produit);
    }

    // Obtenir la liste des produits de la boutique
    public List<Produit> getProduits() {
        return new ArrayList<>(produits);
    }

    // Afficher le stock de la boutique
    public void afficherStock() {
        if (produits.isEmpty()) {
            System.out.println("La boutique est vide.");
        } else {
            System.out.println("Stock de la boutique :");
            for (Produit produit : produits) {
                produit.afficher();
            }
        }
    }
}
