import java.time.LocalDate;

public class ProduitAlimentaire extends Produit {
    private LocalDate dateExpiration;

    // Constructeur qui initialise les attributs de la classe parente (Produit) et l'attribut spécifique (dateExpiration)
    public ProduitAlimentaire(String nom, String description, LocalDate dateExpiration, int prix) {
        super(nom, description, prix);
        this.dateExpiration = dateExpiration;
    }

    // Méthode pour afficher les informations du produit alimentaire
    @Override
    public void afficher() {
        super.afficher(); // Appelle la méthode afficher() de la classe parente pour afficher les informations générales du produit
        System.out.println("Date d'expiration: " + dateExpiration); // Affiche la date d'expiration spécifique au produit alimentaire
    }
}
