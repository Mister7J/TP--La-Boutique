public class ProduitElectronique extends Produit {
    private int dureeGarantie;

    // Constructeur qui initialise les attributs de la classe parente (Produit) et l'attribut spécifique (dureeGarantie)
    public ProduitElectronique(String nom, String description, int dureeGarantie, int prix) {
        super(nom, description, prix);
        this.dureeGarantie = dureeGarantie;
    }

    // Méthode pour afficher les informations du produit électronique
    @Override
    public void afficher() {
        super.afficher(); // Appelle la méthode afficher() de la classe parente pour afficher les informations générales du produit
        System.out.println("Durée de garantie: " + dureeGarantie + " mois"); // Affiche la durée de garantie spécifique au produit électronique
    }
}
