import java.time.LocalDate;

public class ProgrammePrincipal {
    public static void main(String[] args) {
        // Création d'une instance de la classe Boutique
        Boutique maBoutique = new Boutique();

        // Ajout de produits à la boutique
        ajouterProduitsBoutique(maBoutique);

        // Création d'une instance de la classe Panier
        Panier monPanier = new Panier();

        // Ajout de produits au panier
        ajouterProduitsPanier(monPanier);

        // Affichage du prix total du panier
        afficherPrixTotalPanier(monPanier);

        // Affichage du stock de la boutique
        maBoutique.afficherStock();
    }

    // Méthode pour ajouter des produits à la boutique
    private static void ajouterProduitsBoutique(Boutique boutique) {
        boutique.addProduit(new ProduitAlimentaire("Pain", "Baguette française", LocalDate.of(2024, 1, 30), 1));
        boutique.addProduit(new ProduitElectronique("Smartphone", "Dernier modèle haut de gamme", 24, 800));
        boutique.addProduit(new ProduitBoisson("Jus d'orange", "Jus d'orange bio pressé", 500, 3));
    }

    // Méthode pour ajouter des produits au panier
    private static void ajouterProduitsPanier(Panier panier) {
        panier.ajouterProduit(new ProduitAlimentaire("Pain", "Baguette française", LocalDate.of(2024, 1, 30), 1));
        panier.ajouterProduit(new ProduitElectronique("Smartphone", "Dernier modèle haut de gamme", 24, 800));
        panier.ajouterProduit(new ProduitBoisson("Jus de mangue", "Jus de mangue bio ", 500, 3));
    }

    // Méthode pour afficher le prix total du panier
    private static void afficherPrixTotalPanier(Panier panier) {
        System.out.println("Le prix total du panier est : " + panier.prixTotalPanier() + "€");
    }
}
